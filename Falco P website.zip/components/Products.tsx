'use client'

import { useState } from 'react'
import { ShoppingCart, Heart, Eye, Star, ArrowRight } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'
import { useClientTranslation } from '../hooks/useClientTranslation'

export default function Products() {
  const { t } = useClientTranslation()
  const [activeCategory, setActiveCategory] = useState('all')
  const [hoveredProduct, setHoveredProduct] = useState<number | null>(null)

  const categories = [
    { id: 'all', label: t('products.all_products', 'All Products') },
    { id: 'shoes', label: t('products.sport_shoes', 'Sport Shoes') },
    { id: 'clothing', label: t('products.sport_clothing', 'Sport Clothing') },
    { id: 'accessories', label: t('products.accessories', 'Accessories') },
  ]

  const products = [
    {
      id: 1,
      name: 'WING P Pro',
      category: 'shoes',
      price: 299,
      originalPrice: 399,
      rating: 4.9,
      reviews: 124,
      image: '/images/11.jpg',
      badge: 'Best Seller',
      colors: ['Black', 'White', 'Blue'],
      description: 'Premium running shoes with advanced cushioning technology'
    },
    {
      id: 2,
      name: 'WING P Basketball Elite',
      category: 'shoes',
      price: 349,
      originalPrice: 449,
      rating: 4.8,
      reviews: 89,
      image: '/images/12.jpg',
      badge: 'New',
      colors: ['Red', 'Black', 'White'],
      description: 'High-performance basketball shoes for court dominance'
    },
    {
      id: 3,
      name: 'Falco Training Tee',
      category: 'clothing',
      price: 49,
      originalPrice: 69,
      rating: 4.7,
      reviews: 156,
      image: '/images/13.jpg',
      badge: 'Popular',
      colors: ['Black', 'White', 'Gray'],
      description: 'Moisture-wicking training t-shirt for optimal performance'
    },
    {
      id: 4,
      name: 'Falco Compression Shorts',
      category: 'clothing',
      price: 39,
      originalPrice: 59,
      rating: 4.6,
      reviews: 98,
      image: '/images/14.jpg',
      badge: 'Sale',
      colors: ['Black', 'Navy', 'Red'],
      description: 'Compression shorts for enhanced muscle support'
    },
    {
      id: 5,
      name: 'Falco Running Jacket',
      category: 'clothing',
      price: 129,
      originalPrice: 159,
      rating: 4.8,
      reviews: 67,
      image: '/images/15.jpg',
      badge: 'Limited',
      colors: ['Black', 'Blue', 'Green'],
      description: 'Wind-resistant running jacket for all weather conditions'
    },
    {
      id: 6,
      name: 'WING P Soccer Cleats',
      category: 'shoes',
      price: 279,
      originalPrice: 349,
      rating: 4.9,
      reviews: 203,
      image: '/images/16.jpg',
      badge: 'Pro Choice',
      colors: ['White', 'Black', 'Gold'],
      description: 'Professional-grade soccer cleats for field excellence'
    }
  ]

  const filteredProducts = activeCategory === 'all' 
    ? products 
    : products.filter(product => product.category === activeCategory)

  return (
    <section id="products" className="section-padding bg-falco-primary">
      <div className="container-custom">
        {/* Header */}
        <div className="text-center mb-8 sm:mb-12 lg:mb-16 px-4 sm:px-6 lg:px-0">
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-white mb-4 sm:mb-6 tracking-tight">
            {t('products.title', 'PREMIUM COLLECTION')}
          </h2>
          <p className="text-base sm:text-lg lg:text-xl text-gray-400 max-w-3xl mx-auto leading-relaxed">
            {t('products.subtitle', 'Discover our carefully curated selection of high-performance sportswear, designed to elevate your athletic journey with style and precision.')}
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 sm:gap-3 lg:gap-4 mb-8 sm:mb-10 lg:mb-12 px-4 sm:px-6 lg:px-0">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`px-4 sm:px-6 py-2 sm:py-3 rounded-full font-semibold text-sm sm:text-base transition-all duration-300 ${
                activeCategory === category.id
                  ? 'bg-white text-black'
                  : 'bg-white/10 text-white hover:bg-white/20'
              }`}
            >
              {category.label}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8 px-4 sm:px-6 lg:px-0">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="group bg-white/5 backdrop-blur-sm rounded-2xl overflow-hidden hover:bg-white/10 transition-all duration-300 hover:-translate-y-2"
              onMouseEnter={() => setHoveredProduct(product.id)}
              onMouseLeave={() => setHoveredProduct(null)}
            >
              {/* Product Image */}
              <div className="relative h-48 sm:h-56 lg:h-64 overflow-hidden">
                <Image
                  src={product.image}
                  alt={product.name}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
                
                {/* Badge */}
                <div className="absolute top-3 left-3 sm:top-4 sm:left-4">
                  <span className="bg-white text-black px-2 py-1 sm:px-3 sm:py-1 rounded-full text-xs font-bold">
                    {product.badge}
                  </span>
                </div>

                {/* Action Buttons */}
                <div className={`absolute top-3 right-3 sm:top-4 sm:right-4 flex flex-col space-y-1 sm:space-y-2 transition-all duration-300 ${
                  hoveredProduct === product.id ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4'
                }`}>
                  <button className="w-8 h-8 sm:w-10 sm:h-10 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center hover:bg-white hover:text-black transition-colors duration-300">
                    <Heart className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                  </button>
                  <button className="w-8 h-8 sm:w-10 sm:h-10 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center hover:bg-white hover:text-black transition-colors duration-300">
                    <Eye className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                  </button>
                </div>

                {/* Quick Add Button */}
                <div className={`absolute bottom-3 left-3 right-3 sm:bottom-4 sm:left-4 sm:right-4 transition-all duration-300 ${
                  hoveredProduct === product.id ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
                }`}>
                  <button className="w-full bg-white text-black py-2 sm:py-3 rounded-full font-bold hover:bg-gray-100 transition-colors duration-300 flex items-center justify-center space-x-2 text-sm sm:text-base">
                    <ShoppingCart className="w-4 h-4 sm:w-5 sm:h-5" />
                    <span>Add to Cart</span>
                  </button>
                </div>
              </div>

              {/* Product Info */}
              <div className="p-4 sm:p-6">
                <h3 className="text-lg sm:text-xl font-bold text-white mb-2 group-hover:text-gray-300 transition-colors duration-300">
                  {product.name}
                </h3>
                <p className="text-white/60 text-xs sm:text-sm mb-3 sm:mb-4 line-clamp-2">
                  {product.description}
                </p>

                {/* Rating */}
                <div className="flex items-center space-x-2 mb-3 sm:mb-4">
                  <div className="flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3 h-3 sm:w-4 sm:h-4 ${
                          i < Math.floor(product.rating)
                            ? 'text-falco-gold fill-current'
                            : 'text-white/30'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-white/60 text-xs sm:text-sm">
                    {product.rating} ({product.reviews} reviews)
                  </span>
                </div>

                {/* Colors */}
                <div className="flex items-center space-x-2 mb-3 sm:mb-4">
                  <span className="text-white/60 text-xs sm:text-sm">Colors:</span>
                  <div className="flex space-x-1">
                    {product.colors.map((color, index) => (
                      <div
                        key={index}
                        className="w-3 h-3 sm:w-4 sm:h-4 rounded-full border-2 border-white/30"
                        style={{ backgroundColor: color.toLowerCase() }}
                      />
                    ))}
                  </div>
                </div>

                {/* Price */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="text-lg sm:text-xl lg:text-2xl font-bold text-white">
                      ${product.price}
                    </span>
                    {product.originalPrice > product.price && (
                      <span className="text-gray-400 line-through text-sm sm:text-base">
                        ${product.originalPrice}
                      </span>
                    )}
                  </div>
                  <button className="text-white hover:text-gray-300 transition-colors duration-300">
                    <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-8 sm:mt-10 lg:mt-12 px-4 sm:px-6 lg:px-0">
          <Link href="/shop" className="bg-white text-black px-6 sm:px-8 py-3 sm:py-4 rounded-full font-bold text-sm sm:text-base hover:bg-gray-100 transition-colors duration-300 flex items-center space-x-2 mx-auto w-fit">
            <span>{t('products.view_all', 'View All Products')}</span>
            <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5" />
          </Link>
        </div>
      </div>
    </section>
  )
}
