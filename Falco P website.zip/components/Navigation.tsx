'use client'

import { useState, useEffect } from 'react'
import { Menu, X, ShoppingBag, User, Search, ChevronDown } from 'lucide-react'
import Link from 'next/link'
import Image from 'next/image'
import { useClientTranslation } from '../hooks/useClientTranslation'
import LanguageSelector from './LanguageSelector'

export default function Navigation() {
  const { t } = useClientTranslation()
  const [isOpen, setIsOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const navItems = [
    { name: t('nav.home', 'Home'), href: '#home' },
    { name: t('nav.shop', 'Shop'), href: '/shop' },
    { name: t('nav.features', 'Features'), href: '#features' },
    { name: t('nav.nft_collection', 'NFT Collection'), href: 'https://nft.falcop.com/', external: true },
    { name: t('nav.about', 'About'), href: '#about' },
    { name: t('nav.contact', 'Contact'), href: '#contact' },
  ]

  const shopCategories = {
    'Men': {
      'Sportswear': ['T-Shirts', 'Hoodies', 'Shorts', 'Tracksuits', 'Jackets'],
      'Shoes': ['Running Shoes', 'Basketball', 'Training', 'Casual', 'Football Cleats']
    },
    'Women': {
      'Sportswear': ['Sports Bras', 'Leggings', 'Tank Tops', 'Hoodies', 'Jackets', 'Gym Lingerie'],
      'Shoes': ['Running Shoes', 'Training', 'Yoga', 'Casual', 'Cross Training']
    },
    'Kids': {
      'Sportswear': ['T-Shirts', 'Shorts', 'Hoodies', 'Tracksuits'],
      'Shoes': ['Running', 'Basketball', 'Casual', 'Football']
    }
  }

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
      isScrolled 
        ? 'bg-black/95 backdrop-blur-xl border-b border-gray-800' 
        : 'bg-black/90 backdrop-blur-md'
    }`}>
      {/* Additional background layer to prevent text bleeding */}
      <div className="absolute inset-0 bg-black/20"></div>
      <div className="container-custom relative z-10">
        <div className="flex items-center justify-between h-16 sm:h-18 md:h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2 sm:space-x-4 group relative">
            <div className="w-10 h-10 sm:w-12 sm:h-12 md:w-14 md:h-14 rounded-xl overflow-hidden group-hover:scale-105 transition-transform duration-300 shadow-lg">
              <Image
                src="/images/falcop.jpg"
                alt="Falco P Logo"
                width={56}
                height={56}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex flex-col bg-black/50 px-2 py-1 sm:px-3 sm:py-2 rounded-lg backdrop-blur-sm">
              <span className="text-lg sm:text-xl md:text-2xl font-black text-white tracking-tight leading-none relative z-10">
                FALCO P
              </span>
              <span className="text-xs text-gray-400 font-medium tracking-wider relative z-10 hidden sm:block">
                PREMIUM SPORTSWEAR
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-6 xl:space-x-8 2xl:space-x-12">
            {navItems.map((item) => (
              item.name === t('nav.shop', 'Shop') ? (
                /* Shop with Dropdown */
                <div 
                  key={item.name}
                  className="relative group"
                  onMouseEnter={() => setActiveDropdown('shop')}
                  onMouseLeave={() => setActiveDropdown(null)}
                >
                  <Link 
                    href="/shop"
                    className="text-white hover:text-gray-300 transition-colors duration-300 font-semibold text-sm xl:text-base 2xl:text-lg relative group px-2 py-1 flex items-center space-x-1"
                  >
                    <span>{item.name}</span>
                    <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${activeDropdown === 'shop' ? 'rotate-180' : ''}`} />
                    <span className="absolute -bottom-2 left-0 w-0 h-0.5 bg-white group-hover:w-full transition-all duration-300"></span>
                  </Link>
                  
                  {/* Mega Dropdown */}
                  {activeDropdown === 'shop' && (
                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 w-[800px] bg-black/95 backdrop-blur-xl border border-gray-800 rounded-2xl p-8 shadow-2xl">
                      {/* Quick Shop Link */}
                      <div className="mb-6 text-center">
                        <Link 
                          href="/shop" 
                          className="inline-flex items-center space-x-2 bg-falco-accent text-black px-6 py-3 rounded-full font-bold hover:bg-falco-gold transition-colors duration-300"
                        >
                          <ShoppingBag className="w-5 h-5" />
                          <span>Browse All Products</span>
                        </Link>
                      </div>
                      <div className="grid grid-cols-3 gap-8">
                        {Object.entries(shopCategories).map(([category, subcategories]) => (
                          <div key={category} className="space-y-4">
                            <h3 className="text-falco-accent font-bold text-lg mb-4 border-b border-gray-800 pb-2">
                              {category}
                            </h3>
                            {Object.entries(subcategories).map(([subcat, items]) => (
                              <div key={subcat} className="space-y-2">
                                <h4 className="text-white font-semibold text-sm mb-2">
                                  {subcat}
                                </h4>
                                <ul className="space-y-1">
                                  {items.map((item) => (
                                    <li key={item}>
                                      <Link
                                        href={`/shop/${category.toLowerCase()}/${subcat.toLowerCase()}/${item.toLowerCase().replace(/\s+/g, '-')}`}
                                        className="text-gray-400 hover:text-falco-accent transition-colors duration-300 text-sm block py-1"
                                      >
                                        {item}
                                      </Link>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            ))}
                          </div>
                        ))}
                      </div>
                      
                      {/* Featured Banner */}
                      <div className="mt-8 pt-6 border-t border-gray-800">
                        <div className="bg-gradient-to-r from-falco-accent to-falco-gold rounded-xl p-4 text-center">
                          <p className="text-falco-primary font-bold text-sm">
                            🔥 NEW ARRIVALS - UP TO 30% OFF
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ) : item.external ? (
                <a
                  key={item.name}
                  href={item.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-white hover:text-gray-300 transition-colors duration-300 font-semibold text-sm xl:text-base 2xl:text-lg relative group px-2 py-1"
                >
                  {item.name}
                  <span className="absolute -bottom-2 left-0 w-0 h-0.5 bg-white group-hover:w-full transition-all duration-300"></span>
                </a>
              ) : (
                <Link
                  key={item.name}
                  href={item.href}
                  className="text-white hover:text-gray-300 transition-colors duration-300 font-semibold text-sm xl:text-base 2xl:text-lg relative group px-2 py-1"
                >
                  {item.name}
                  <span className="absolute -bottom-2 left-0 w-0 h-0.5 bg-white group-hover:w-full transition-all duration-300"></span>
                </Link>
              )
            ))}
          </div>

          {/* Action Buttons */}
          <div className="hidden lg:flex items-center space-x-2 xl:space-x-4 2xl:space-x-6">
            <LanguageSelector />
            <button className="p-2 xl:p-3 text-white hover:text-gray-300 transition-colors duration-300 hover:bg-white/10 rounded-full">
              <Search className="w-4 h-4 xl:w-5 xl:h-5 2xl:w-6 2xl:h-6" />
            </button>
            <button className="p-2 xl:p-3 text-white hover:text-gray-300 transition-colors duration-300 hover:bg-white/10 rounded-full">
              <User className="w-4 h-4 xl:w-5 xl:h-5 2xl:w-6 2xl:h-6" />
            </button>
            <button className="p-2 xl:p-3 text-white hover:text-gray-300 transition-colors duration-300 hover:bg-white/10 rounded-full relative">
              <ShoppingBag className="w-4 h-4 xl:w-5 xl:h-5 2xl:w-6 2xl:h-6" />
              <span className="absolute -top-1 -right-1 w-3 h-3 xl:w-4 xl:h-4 2xl:w-5 2xl:h-5 bg-white text-black text-xs rounded-full flex items-center justify-center font-bold">
                0
              </span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="lg:hidden p-2 text-white hover:text-falco-accent transition-colors duration-300"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="lg:hidden absolute top-full left-0 right-0 bg-falco-primary/95 backdrop-blur-md border-t border-white/10 mobile-padding max-h-[80vh] overflow-y-auto">
            <div className="py-6 space-y-4">
              {navItems.map((item) => (
                item.external ? (
                  <a
                    key={item.name}
                    href={item.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block text-white/80 hover:text-falco-accent transition-colors duration-300 font-medium py-3 px-2"
                    onClick={() => setIsOpen(false)}
                  >
                    {item.name}
                  </a>
                ) : (
                  <Link
                    key={item.name}
                    href={item.href}
                    className="block text-white/80 hover:text-falco-accent transition-colors duration-300 font-medium py-3 px-2"
                    onClick={() => setIsOpen(false)}
                  >
                    {item.name}
                  </Link>
                )
              ))}
              
              {/* Mobile Shop Section */}
              <div className="border-t border-white/10 pt-4">
                <div className="flex items-center justify-between mb-4 px-2">
                  <h3 className="text-falco-accent font-bold text-lg">Shop</h3>
                  <Link 
                    href="/shop"
                    className="bg-falco-accent text-black px-4 py-2 rounded-full text-sm font-bold hover:bg-falco-gold transition-colors duration-300"
                    onClick={() => setIsOpen(false)}
                  >
                    Browse All
                  </Link>
                </div>
                {Object.entries(shopCategories).map(([category, subcategories]) => (
                  <div key={category} className="mb-6">
                    <h4 className="text-white font-semibold text-base mb-3 px-2 border-l-2 border-falco-accent pl-3">
                      {category}
                    </h4>
                    {Object.entries(subcategories).map(([subcat, items]) => (
                      <div key={subcat} className="mb-4 px-4">
                        <h5 className="text-gray-300 font-medium text-sm mb-2">
                          {subcat}
                        </h5>
                        <div className="grid grid-cols-2 gap-2">
                          {items.map((item) => (
                            <Link
                              key={item}
                              href={`/shop/${category.toLowerCase()}/${subcat.toLowerCase()}/${item.toLowerCase().replace(/\s+/g, '-')}`}
                              className="text-gray-400 hover:text-falco-accent transition-colors duration-300 text-xs py-1"
                              onClick={() => setIsOpen(false)}
                            >
                              {item}
                            </Link>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
              
              {/* Mobile Language Selector */}
              <LanguageSelector mobile className="mt-6" />
              
              <div className="flex items-center justify-center space-x-6 pt-6 border-t border-white/10">
                <button className="p-3 text-white/80 hover:text-falco-accent transition-colors duration-300">
                  <Search className="w-5 h-5" />
                </button>
                <button className="p-3 text-white/80 hover:text-falco-accent transition-colors duration-300">
                  <User className="w-5 h-5" />
                </button>
                <button className="p-3 text-white/80 hover:text-falco-accent transition-colors duration-300 relative">
                  <ShoppingBag className="w-5 h-5" />
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-falco-accent text-falco-primary text-xs rounded-full flex items-center justify-center">
                    0
                  </span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}
