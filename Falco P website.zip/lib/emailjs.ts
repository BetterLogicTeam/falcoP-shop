// EmailJS Configuration
export const EMAILJS_CONFIG = {
  SERVICE_ID: 'service_ob9ubpu',
  TEMPLATE_ID: 'template_ybx53mu',
  PUBLIC_KEY: 'nhVy8H-_GcHzOmFbI',
}

export const SUBSCRIPTION_TEMPLATE_PARAMS = {
  subscriber_email: '',
  subscription_date: '',
  source: 'Falco P Website - Newsletter Section',
  message: 'New subscriber interested in Falco P NFT collections, exclusive drops, community events, and brand updates.',
}
